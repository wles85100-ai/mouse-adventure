鼠除大作戰｜GitHub Pages 網頁遊戲

檔案：index.html
不必安裝程式、不必使用 Terminal、不必搭配外部圖片。

Windows 電腦先試玩：
1. 直接在檔案總管找到 index.html。
2. 用 Microsoft Edge 或 Chrome 開啟。
3. 點「選擇關卡」，點第 1 關，即可開始。

上傳到 GitHub（已有 Repository）：
1. 登入 github.com，進入你的遊戲 Repository。
2. 選 Add file > Upload files。
3. 上傳 index.html（一定要叫 index.html，且放在 Repository 最上層）。
4. 點 Commit changes。
5. 進入 Settings > Pages。
6. 在 Build and deployment 的 Source 選 Deploy from a branch。
7. Branch 選 main、資料夾選 /(root)，按 Save。
8. 等待 GitHub 部署後，點 Pages 所顯示的網站網址。
   常見網址形式：https://你的帳號.github.io/你的Repository名稱/

遊戲內容：
* 30 關、每 5 關變換一個主題背景，關卡存檔在瀏覽器 localStorage
* 3 種難度、無盡模式
* 普通／快速／黃金／愛心／炸彈／國王地鼠
* 黃金 +5、炸彈 -3、愛心增加 3 秒
* Combo 加分、FEVER、國王 Boss、三星、結算、暫停
* 滑鼠、手機觸控、合成音效、支援裝置的震動

這是可玩的 Canvas 原型版，角色目前由程式繪製，不是先前概念圖裡逐格切出的 Sprite Sheet；等正式圖片資產完成可再替換。

注意：手機震動僅在瀏覽器及裝置支援 navigator.vibrate 時生效；部分 iOS 裝置不支援。
