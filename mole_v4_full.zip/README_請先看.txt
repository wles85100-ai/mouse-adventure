鼠除大作戰 V4.0（2026-11-08）
內容：index.html、assets/ 舊版完整素材與 V4.0 新素材、SpriteSheets/ 組合圖。

新增素材：
assets/moles/chest/chest_01.png ～ chest_12.png
assets/moles/rainbow/rainbow_01.png ～ rainbow_12.png
assets/effects/boom/boom_01.png ～ boom_08.png
assets/effects/chest_open/chest_open_01.png ～ chest_open_08.png

上傳 GitHub Pages：
1. 在你原本的 repository 根目錄更新 index.html。
2. 將四個新資料夾連同內部 PNG 上傳到相應 assets 路徑。
3. 你原有的 assets/moles/normal、fast、gold、heart、bomb、boss 以及 backgrounds 不必重新上傳。
4. 不要直接把 zip 檔上傳到 GitHub 當遊戲；ZIP 必須在本機解壓縮。
5. 完成後到網站按 Ctrl+F5 刷新，首頁應出現 V4.0。

新功能：神祕寶箱（每場至多2次、抽金幣/加時/冰凍/雙倍/稀有禮物）、彩虹地鼠（稀有+12分與20金幣）、搞笑炸彈（扣3分、中斷Combo、煙霧與暈眩效果、不扣時間）；金幣禮物存在同一瀏覽器 LocalStorage。

備註：新角色素材由 AI 素材板裁切及去背製作，部分細小邊緣可能殘留土色；角色 GIF 及動畫仍須在真實瀏覽器實測。
